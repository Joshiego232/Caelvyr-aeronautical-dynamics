# Caelvyr Aeronautical Dynamics — Changelog

## V1.0.0 — Mobile Edition
- Added animated studio intro and startup loading screen.
- Added a new title screen with Play, Settings, Plugins/Add-ons/Patches, Check for Updates, and Changelog.
- Added guided hangar aircraft selection, 3D airport selection, and runway/gate start-position flow.
- Added a settings hub for graphics, touch controls, flight assistance, keyboard bindings, and gamepad mappings.
- Added an online GitHub release checker and APK download hand-off.
- Added native Android bridge for app version reporting and opening APK download links.
- Retained the existing simulator flight model, aircraft, navigation map, replay, liveries, and controller logic.
