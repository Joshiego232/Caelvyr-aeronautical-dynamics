# Caelvyr Aeronautical Dynamics — Android project

This project wraps the standalone simulator in a landscape, full-screen Android WebView. The bundled game is `app/src/main/assets/index.html`; it remains available offline. Internet is used only for the optional GitHub update check and release downloads.

## What is in this build

- Animated studio introduction and system loading screen.
- New title menu: Play, Settings, Plugins/Add-ons/Patches, Check for Updates, and Changelog.
- Guided four-step setup: 3D Hangar / aircraft selection, 3D airport selection, runway/gate/landing start, and flight configuration.
- Shared settings hub for graphics, on-screen controls, flight-assistance style, and keyboard/controller bindings.
- GitHub release update checker. APK downloads still require Android's confirmation/install step; Android does not permit an app to silently install its own update.

## First-time GitHub setup (tablet-friendly)

1. Create a **public** GitHub repository named `caelvyr-aeronautical-dynamics` if you want the in-app update checker to work without a GitHub sign-in. Private repositories are not currently supported by the in-app release lookup.
2. Upload `Caelvyr_Android_Project.zip` to the repository root.
3. Before adding the workflow, open **Settings → Secrets and variables → Actions → New repository secret** and create the four signing secrets described in `SIGNING_SETUP.md`: `CAELVYR_KEYSTORE_BASE64`, `CAELVYR_KEYSTORE_PASSWORD`, `CAELVYR_KEY_ALIAS`, and `CAELVYR_KEY_PASSWORD`. Do not upload the encoded key or keystore as a normal repository file.
4. Create `.github/workflows/build-apk.yml` at the repository root using the separate workflow file provided with this update. If a workflow already exists there, replace its contents. The workflow extracts the ZIP, builds a signed release APK, and publishes it to the rolling `mobile-latest` GitHub Release.
5. Commit the workflow. A push to `main` starts the build automatically. You can also run it from **Actions → Build and Publish Caelvyr Android APK → Run workflow**.
6. Download the APK artifact for a manual install, or let the in-game updater find the published APK later.

## First-time signing key

A persistent signing identity is essential for updates. Android only allows an installed app to be updated by an APK with the same package ID and compatible signing key. The CI workflow uses repository secrets for the release key, so every future release is signed consistently. See `SIGNING_SETUP.md` for the values to store as Actions secrets. Keep the signing information private and make a backup somewhere secure.

If you installed an earlier **debug** APK from a previous workflow, the stable release APK will install as a separate production app (`com.skyboundsystems.caelvyr`) rather than replace the debug package (`com.skyboundsystems.caelvyr.debug`). After verifying the release version works, you can remove the older debug app. Future production APKs from this workflow will update the production app in place.

## Turn on Check for Updates

On first use, tap **Check for Updates** and enter the public GitHub repository URL once, for example `https://github.com/your-name/caelvyr-aeronautical-dynamics`. The app saves this choice on the device, then compares the installed app version with the version in the newest published GitHub release. The updater expects an APK asset named `Caelvyr-Aeronautical-Dynamics.apk` attached to the `mobile-latest` release.

The update button opens the APK download through Android's browser/download handler. After it finishes, open the downloaded APK and tap **Install**. This explicit confirmation is required by Android.

## How to publish future updates

1. Replace the ZIP in the GitHub repository with the updated `Caelvyr_Android_Project.zip` (upload a new ZIP with the same name and commit the replacement).
2. Update `app/build.gradle`'s `versionName` (for example, `1.0.0` → `1.0.1`) **and increase `versionCode`** (for example, `1` → `2`), then add notes to the top of `CHANGELOG.md` before building; keep the version number in the bundled HTML fallback in sync by changing `CV_APP_VERSION_FALLBACK` and the initial title-screen release text in `index.html` if that release is edited manually. The native Android bridge supplies the release APK's package version to the running UI.
3. Commit the new project ZIP and version/changelog changes. The workflow builds the release and refreshes `mobile-latest`; users' Check for Updates button will then detect the higher version.
4. Preserve the Actions secrets and signing key. Never generate a different signing key for a later release.

## Build configuration

- Package ID: `com.skyboundsystems.caelvyr` for release builds.
- Android min SDK: 23; target/compile SDK: 35.
- Java 17; Gradle 8.9; Android Gradle plugin 8.7.3.
- Existing flight simulation features remain bundled in the HTML.
