# Caelvyr Aeronautical Dynamics — Android project

This project wraps the standalone simulator HTML in an Android WebView app. The game is bundled locally at `app/src/main/assets/index.html` and does not need a server to load the page.

## Easiest mobile-only route: build an APK with GitHub Actions

This repository includes `.github/workflows/build-apk.yml`. GitHub's cloud runner installs Java, Android SDK and Gradle, builds a debug APK, and attaches it as a downloadable workflow artifact. No Android SDK or computer is required on your tablet.

1. On your Android tablet, open Chrome and sign in or create an account at https://github.com.
2. Create a **new repository**. Name it `caelvyr-aeronautical-dynamics`. For the simplest setup, choose **Public**; if you choose Private, make sure your account can use Actions. Do not add a README, license, or `.gitignore` when creating it.
3. Download and extract `Caelvyr_Android_Project.zip` on your tablet using the Files app. You should see the project folder containing `app`, `.github`, `build.gradle`, `settings.gradle`, and `gradle.properties`.
4. Upload the extracted **project contents** into the repository root, not the ZIP itself. On the repository page, choose **Add file → Upload files**. Select the files and folders from the extracted project if the browser's file picker supports folder selection. Confirm the `.github/workflows/build-apk.yml` file is present at that exact path. If the mobile picker cannot upload folders, use a GitHub Codespace as described below or another upload method that preserves folder paths.
5. Commit the uploaded files to the `main` branch.
6. Open the repository's **Actions** tab. Select **Build Caelvyr Android APK**. If prompted, enable GitHub Actions. Tap **Run workflow**, select `main`, then tap **Run workflow** again.
7. Wait for the run to finish with a green check mark. Open the completed run and scroll to **Artifacts**.
8. Tap `Caelvyr-Aeronautical-Dynamics-debug-apk` to download the ZIP artifact. Open it in the Files app and extract it; inside is the `.apk` file.
9. Tap the APK. If Android blocks installation, open **Settings → Security/Privacy → Install unknown apps**, allow permission for the app you used to open the file (usually Files or Chrome), then return and install. Turn that permission back off afterward if desired.
10. Launch **Caelvyr Aeronautical Dynamics** from your app drawer. The build is a debug/test APK; it is suitable for personal installation, not a Play Store release.

### If mobile upload cannot preserve folders

Use https://github.com/features/codespaces to open a browser-based development environment, or use a trusted Git client that can upload folders while preserving paths. The workflow file must live at `.github/workflows/build-apk.yml`, and the Android files must stay in their original directory structure. A ZIP uploaded as a single repository file will not run the workflow by itself.

## Build locally (optional)

Open this folder in Android Studio, let Gradle sync, then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**. The debug APK is generated at `app/build/outputs/apk/debug/`.

## Technical notes

- The app launches in landscape and immersive full-screen mode.
- JavaScript, DOM storage, and hardware acceleration are enabled. The HTML is served via AndroidX `WebViewAssetLoader`; direct `file://` access is disabled.
- Keyboard/controller mapping persistence and gamepad behavior depend on the Android System WebView and device hardware.
- The APK built by GitHub Actions is a debug-signed build. Create a separate signed release build and securely retain its signing key before distributing publicly or publishing to Google Play.
