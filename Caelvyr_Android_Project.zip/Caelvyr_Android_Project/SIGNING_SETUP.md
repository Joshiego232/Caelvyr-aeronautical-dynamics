# Release signing setup (required once)

The actual values for the release key are provided separately in `Caelvyr_GitHub_Signing_Secrets.txt`. That file contains a private encoded signing key and passwords. Treat it like a password manager export: do not upload it to GitHub as a file, do not paste it into a commit or issue, and do not share it publicly.

On GitHub in your tablet browser:

1. Open the Caelvyr repository → **Settings**.
2. Under **Security**, open **Secrets and variables → Actions**.
3. Tap **New repository secret** and create each of these secrets using the matching value from the separate setup file:
   - `CAELVYR_KEYSTORE_BASE64`
   - `CAELVYR_KEYSTORE_PASSWORD`
   - `CAELVYR_KEY_ALIAS`
   - `CAELVYR_KEY_PASSWORD`
4. Never store the key as a normal repository file. The workflow decodes it only temporarily on GitHub's build runner.
5. Keep an offline backup of the signing-key setup file somewhere private. If this key is lost, future APKs will not be able to update installations signed with it.
